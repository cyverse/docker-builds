Reference genomes from Ensembl PLant release 16, gene names and descriptions
Format tab delimited gene_id locus_name description
Sheldon Mckay mckays@cshl.edu Dec 6, 2012

