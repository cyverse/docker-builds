Reference genomes from Ensembl PLant release 13,gene names and descriptions
Format tab delimited gene_id locus_name description
Sheldon Mckay mckays@cshl.edu Marc 11, 2012
